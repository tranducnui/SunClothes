package com.example.ecommerce_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
