package com.example.ecommerce_be.constants;

public enum Status {
    NEW,
    ON_SALE
}
