package com.example.ecommerce_be.constants;

public class Constants {
    public static int ACTIVE = 1;
    public static int INACTIVE = 0;
}
