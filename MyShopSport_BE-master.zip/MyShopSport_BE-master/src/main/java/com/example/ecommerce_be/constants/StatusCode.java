package com.example.ecommerce_be.constants;

public class StatusCode {
    public static String SUCCESS = "200";
    public static String NOT_FOUND = "404";
    public static String ERROR = "500";
}
